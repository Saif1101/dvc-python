# Prompt: Module Guide

## When to use
Generate one module guide per major subsystem or top-level directory.
Generate these after the architecture overview exists so you can cross-reference it.
Generate them before the API reference since the API reference links to modules.

---

## Variables
Replace these before running:
- `{MODULE_NAME}` — human-readable module name, e.g. "Authentication"
- `{MODULE_PATH}` — directory path, e.g. "src/auth"
- `{OUTPUT_PATH}` — e.g. "docs/modules/auth.md"

---

## Pre-flight searches

```bash
# 1. Module public surface
ccc search "{MODULE_NAME} public interface exports functions classes" --top-k 10

# 2. Internal implementation
ccc search "{MODULE_NAME} internal implementation logic how it works" --top-k 10

# 3. Who depends on this module
ccc search "imports {MODULE_NAME} uses {MODULE_PATH} depends on" --top-k 8

# 4. What this module depends on
ccc search "{MODULE_NAME} dependencies imports external calls" --top-k 6

# 5. Tests — reveal intended behaviour
ccc search "test {MODULE_NAME} spec describe it should" --top-k 8

# 6. Configuration and setup
ccc search "{MODULE_NAME} configuration setup initialise config options" --top-k 4
```

Pack results:
```bash
repomix --include "<all files from above, deduplicated>" \
        --compress \
        --output /tmp/module-context.xml
```

---

## Prompt

```
You are writing a Module Guide for the {MODULE_NAME} module of a legacy codebase.
Module path: {MODULE_PATH}
Output: {OUTPUT_PATH}
Source: /tmp/module-context.xml

Read the full file including the test files — tests reveal intended behaviour
that production code often obscures.

Write {OUTPUT_PATH} using this exact structure:

---

---
title: {MODULE_NAME}
sidebar_label: {MODULE_NAME}
sidebar_position: 1
---

# {MODULE_NAME}

## Purpose
2–3 sentences. What is this module responsible for? What does it own?
What would break if it didn't exist?

## Quick Start
The fastest way a developer can use this module.
Show a minimal working code example if one can be inferred from the tests.
```<language>
# minimal example
```

## Public Interface
Document every exported function, class, or symbol.
For each:

### `FunctionName(param: Type): ReturnType`
What it does. When to call it. What it returns.
Side effects, if any. Errors it can raise/throw.

Use actual signatures from the source — do not invent them.
Flag invented signatures with [ASSUMPTION: signature inferred from usage].

## Internal Design
How it works internally. Not a line-by-line walkthrough — a conceptual
explanation of the key design decisions and data flow within the module.

Include a Mermaid diagram if there are non-trivial internal flows:
```mermaid
graph TD
    A[Input] --> B[Validation]
    B --> C{Cached?}
    C -->|Yes| D[Return cache]
    C -->|No| E[Process]
    E --> F[Store in cache]
    F --> D
```

## Dependencies

### This module depends on:
| Module | What it uses | Why |
|--------|-------------|-----|
| ModuleA | `functionX()` | For Y |

### Modules that depend on this:
| Module | How it uses this | Notes |
|--------|-----------------|-------|
| ModuleB | Calls `functionZ()` | On every request |

Link to the relevant module guides: see [ModuleA](./module-a.md)

## Configuration
List every config key, environment variable, or option this module reads.
| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `AUTH_SECRET` | string | required | Used to sign tokens |

## Error Handling
What errors/exceptions does this module define or propagate?
How should callers handle them?
What happens on partial failure?

## Known Issues / Legacy Notes
`:::danger Legacy Pattern` admonitions you spotted. Be specific.
Anything a developer should be cautious about when working in this module.
Known bugs or workarounds that appear in the code.

---

After writing, run:
```bash
ccc search "{MODULE_NAME} edge cases error handling special cases" --top-k 5
```
Check if any error-handling or edge-case files were missed. Amend if needed.

Resolve every [ASSUMPTION] before marking the doc complete.
List any [ASSUMPTION] tags that could not be resolved as a
"Needs Human Review" section at the bottom.
```
