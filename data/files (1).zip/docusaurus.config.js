// docusaurus.config.js
// Place this at the root of your Docusaurus site (my-docs/)
// Generated docs go into my-docs/docs/

const { themes } = require("prism-react-renderer");

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: "Codebase Documentation",
  tagline: "Generated with CocoIndex + Repomix + Claude Code",
  favicon: "img/favicon.ico",

  url: "https://your-domain.com",       // change to your actual URL
  baseUrl: "/",

  onBrokenLinks: "warn",               // warn (not throw) — generated docs may have gaps
  onBrokenMarkdownLinks: "warn",

  i18n: {
    defaultLocale: "en",
    locales: ["en"],
  },

  // ── Mermaid support (built-in Docusaurus v3) ──────────────────────────────
  markdown: {
    mermaid: true,
  },
  themes: ["@docusaurus/theme-mermaid"],

  presets: [
    [
      "classic",
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: "./sidebars.js",
          routeBasePath: "/",           // serve docs at root, not /docs/
          editUrl: undefined,           // disable "Edit this page" links
          showLastUpdateTime: true,
          showLastUpdateAuthor: false,
        },
        blog: false,                    // no blog needed for code docs
        theme: {
          customCss: "./src/css/custom.css",
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      navbar: {
        title: "Codebase Docs",
        items: [
          {
            type: "docSidebar",
            sidebarId: "architectureSidebar",
            position: "left",
            label: "Architecture",
          },
          {
            type: "docSidebar",
            sidebarId: "modulesSidebar",
            position: "left",
            label: "Modules",
          },
          {
            type: "docSidebar",
            sidebarId: "apiSidebar",
            position: "left",
            label: "API Reference",
          },
        ],
      },

      // ── Search (local) ──────────────────────────────────────────────────
      // Uses @docusaurus/plugin-search-local — install with:
      // npm install @easyops-cn/docusaurus-search-local
      // Then uncomment below and remove the themes entry at the bottom.

      // algolia: {                    // use this instead for Algolia DocSearch
      //   appId: "YOUR_APP_ID",
      //   apiKey: "YOUR_SEARCH_API_KEY",
      //   indexName: "YOUR_INDEX_NAME",
      // },

      prism: {
        theme: themes.github,
        darkTheme: themes.dracula,
        // Add language highlighting for your stack
        additionalLanguages: [
          "python", "java", "go", "ruby", "rust",
          "bash", "json", "yaml", "toml", "sql",
        ],
      },

      // ── Admonition icons ────────────────────────────────────────────────
      // The pipeline uses :::warning, :::danger, :::note for flags.
      // These render out of the box in Docusaurus — no config needed.
    }),

  // ── Local search plugin ──────────────────────────────────────────────────
  plugins: [
    [
      require.resolve("@easyops-cn/docusaurus-search-local"),
      {
        hashed: true,
        indexDocs: true,
        searchResultLimits: 8,
        docsRouteBasePath: "/",
      },
    ],
  ],
};

module.exports = config;
