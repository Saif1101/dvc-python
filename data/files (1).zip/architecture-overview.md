# Prompt: Architecture Overview

## When to use
Generate this doc first, before any module guides. It gives readers the map
before the territory. Update it last after all module guides exist, so it
can reference them accurately.

---

## Pre-flight searches

Run all of these before writing. Pack all results into a single Repomix call.

```bash
# 1. Entry points and bootstrap
ccc search "main entry point application startup bootstrap initialisation" --top-k 8

# 2. Core domain logic
ccc search "core business logic domain models central service layer" --top-k 8

# 3. Data layer
ccc search "database ORM data access repository models schema" --top-k 8

# 4. External integrations
ccc search "external API third party integration client HTTP service" --top-k 8

# 5. Configuration
ccc search "configuration environment variables settings feature flags" --top-k 6

# 6. Request lifecycle (if web app)
ccc search "middleware router request response handler pipeline" --top-k 6
```

Pack all results:
```bash
repomix --include "<all files from above searches, deduplicated>" \
        --compress \
        --output /tmp/arch-context.xml
```

---

## Prompt

```
You are writing an Architecture Overview for a legacy codebase.
Your source is the Repomix output at /tmp/arch-context.xml.

Read the full file. Then write docs/architecture/overview.md using
this exact structure:

---

---
title: Architecture Overview
sidebar_label: Overview
sidebar_position: 1
---

# Architecture Overview

## Purpose
One paragraph. What does this system do? Who uses it? What problem does it solve?
Infer from the code if no README exists. Flag as [ASSUMPTION] if inferred.

## System Diagram
A Mermaid diagram showing the major subsystems and how they relate.
Use `graph TD` or `graph LR`. Show data flow with arrows.
Label each node with the subsystem name and a one-line description.

```mermaid
graph TD
    A[Entry Point<br/>handles incoming requests] --> B[Router]
    B --> C[Auth Middleware]
    ...
```

## Major Subsystems
One section per major subsystem. For each:
- **Name**: What it's called in the codebase
- **Responsibility**: What it owns
- **Key files**: 2–4 most important files
- **Link**: Reference to the module guide if it exists: see [Module Name](../modules/<n>.md)

## Data Flow
Describe how a typical request or operation flows through the system,
end to end. Use a Mermaid sequenceDiagram if the flow is complex.

## External Integrations
List every external service, API, or system this codebase depends on.
For each: name, purpose, which module owns the integration.

## Technology Stack
A table:
| Layer | Technology | Notes |
|-------|-----------|-------|
| Language | ... | version if visible |
| Framework | ... | |
| Database | ... | |
| ... | | |

## Known Technical Debt
Flag [LEGACY] patterns you spotted during retrieval.
Be specific: name the file/pattern and why it's outdated.
This section is important — readers of legacy codebases need to know
what to trust and what to treat with caution.

---

After writing, re-run:
```bash
ccc search "architecture overview system design top level structure" --top-k 6
```
Check if any critical files were missed. Amend if needed.

Resolve every [ASSUMPTION] with a targeted search before finalising.
```
