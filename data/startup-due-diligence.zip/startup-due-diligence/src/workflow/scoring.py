from typing import Literal

def _get_output(outputs: list, agent_name: str) -> dict:
    for o in outputs:
        if o.get("agent") == agent_name and o.get("success"):
            return o.get("output", {})
    return {}


async def quick_score_node(state: dict) -> dict:
    """Fast preliminary scoring before expensive analysis."""
    research = state.get("research_outputs", [])
    score = 0
    reasons = []
    
    company = _get_output(research, "company_profiler")
    funding = company.get("total_funding", {}).get("amount", 0)
    if funding > 1_000_000:
        score += 20
        reasons.append(f"Raised ${funding:,}")
    
    market = _get_output(research, "market_researcher")
    tam = market.get("tam", {}).get("amount", 0)
    if tam > 1_000_000_000:
        score += 30
        reasons.append(f"TAM ${tam:,}")
    
    team = _get_output(research, "team_investigator")
    if team.get("previous_exits"):
        score += 25
        reasons.append("Team has exits")
    
    print(f"Quick score: {score}/100 - {', '.join(reasons) or 'No signals'}")
    
    return {
        "preliminary_score": score,
        "current_stage": "scored"
    }


def route_by_score(state: dict) -> Literal["proceed", "reject"]:
    score = state.get("preliminary_score", 0)
    if score >= 40:
        return "proceed"
    print(f"Early rejection: score {score} < 40")
    return "reject"