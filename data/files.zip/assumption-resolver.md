# Prompt: Assumption Resolver

## When to use
After any doc generation pass, resolve all [ASSUMPTION] flags that were left
in the output. Run this as a dedicated pass rather than interrupting the main
writing flow — it's more efficient to write first and verify second.

---

## Pre-flight

```bash
# Find all unresolved assumptions across all docs
grep -rn "\[ASSUMPTION" docs/ --include="*.md"
```

This gives you a list of every assumption that needs verification.

---

## Prompt

```
You are resolving flagged assumptions in documentation for a legacy codebase.

Run this command and read the output:
```bash
grep -rn "\[ASSUMPTION" docs/ --include="*.md"
```

For each [ASSUMPTION] found, follow this resolution loop:

---

ASSUMPTION RESOLUTION LOOP:

1. READ the assumption text carefully.
   Understand exactly what is being assumed and why verification matters.

2. FORM a targeted search query.
   The query should directly target evidence that would confirm or refute
   the assumption. Be specific — general queries return noise.

3. SEARCH:
   ```bash
   ccc search "<targeted query>" --top-k 6
   ```

4. PACK the results:
   ```bash
   repomix --include "<results>" --compress --output /tmp/verify-<N>.xml
   ```

5. READ /tmp/verify-<N>.xml

6. DECIDE:
   a. CONFIRMED — evidence supports the assumption
      → Replace [ASSUMPTION: text] with the confirmed fact.
      → Optionally add a note: *(confirmed via `src/path/to/file.py`)*

   b. REFUTED — evidence contradicts the assumption
      → Replace with the correct information from the source.
      → Note what was wrong: *(corrected: original assumption was X, actual behaviour is Y)*

   c. PARTIALLY CONFIRMED — evidence is mixed or incomplete
      → Keep part of the assumption, correct the part that's wrong.
      → Flag the unresolved part: [NEEDS REVIEW: <specific remaining question>]

   d. UNRESOLVABLE — no relevant code found after 2+ search attempts
      → Escalate: [NEEDS HUMAN REVIEW: <assumption text> — could not locate
         relevant code. Suggested places to look: <your best guess>]

7. REPEAT for every [ASSUMPTION] in the list.

---

After resolving all assumptions, run:
```bash
grep -rn "\[ASSUMPTION" docs/ --include="*.md"
```

If any remain, they must be escalated to [NEEDS HUMAN REVIEW] — do not leave
raw [ASSUMPTION] tags in the final docs.

Produce a resolution summary:
```
## Assumption Resolution Summary

### Confirmed (N)
- auth.md line 42: Token expiry confirmed — 24h default in src/auth/config.py
- ...

### Corrected (N)
- api.md line 87: Rate limit is 100 req/min, not 60 — found in middleware/throttle.js
- ...

### Needs Human Review (N)
- modules/payments.md line 103: Webhook retry logic unclear — no retry code found
  Suggested: check src/webhooks/ or ask the payments team
- ...
```
```
