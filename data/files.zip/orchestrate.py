#!/usr/bin/env python3
"""
orchestrate.py — CocoIndex + Repomix + Claude Code documentation pipeline

Usage:
    python orchestrate.py --mode full          # Generate all docs from scratch
    python orchestrate.py --mode module --name auth --path src/auth
    python orchestrate.py --mode refresh --doc docs/modules/auth.md
    python orchestrate.py --mode api
    python orchestrate.py --mode architecture
    python orchestrate.py --mode resolve       # Resolve all [ASSUMPTION] flags
"""

import argparse
import subprocess
import sys
import os
from pathlib import Path
from datetime import datetime

# ── Config ────────────────────────────────────────────────────────────────────

DOCS_DIR = Path("docs")
PROMPTS_DIR = Path(".claude/prompts")   # where your prompt files live
TMP = Path("/tmp")
COCOINDEX_SCRIPT = "index_flow.py"
LLM_MODEL = "claude-sonnet-4-20250514"

# Search queries per doc type
SEARCHES = {
    "architecture": [
        ("main entry points application startup bootstrap", 8),
        ("core business logic domain models central service", 8),
        ("database ORM data access repository models", 8),
        ("external API third party integration HTTP client", 8),
        ("configuration environment variables settings", 6),
        ("middleware router request response handler pipeline", 6),
    ],
    "api": [
        ("HTTP routes endpoints URL path GET POST PUT DELETE", 12),
        ("controller handler request response route", 10),
        ("authentication authorisation middleware guard route", 8),
        ("request validation schema body params validator", 8),
        ("response serializer formatter output transform", 6),
        ("error response status code HTTP error handler", 6),
        ("API test integration test endpoint supertest", 10),
    ],
}

# ── Helpers ───────────────────────────────────────────────────────────────────

def run(cmd: str, capture: bool = True) -> str:
    """Run a shell command and return stdout."""
    print(f"  $ {cmd}")
    result = subprocess.run(
        cmd, shell=True, capture_output=capture, text=True
    )
    if result.returncode != 0 and not capture:
        print(f"  ✗ Command failed: {result.stderr}", file=sys.stderr)
    return result.stdout.strip() if capture else ""


def cocoindex_search(query: str, top_k: int = 10) -> list[str]:
    """Run a CocoIndex semantic search and return file paths."""
    output = run(f'ccc search "{query}" --top-k {top_k}')
    files = []
    for line in output.splitlines():
        parts = line.strip().split()
        if len(parts) >= 2:
            # ccc returns: <score> <filepath>
            filepath = parts[1]
            if Path(filepath).exists():
                files.append(filepath)
    return files


def repomix_pack(files: list[str], output: Path) -> int:
    """Pack files with Repomix. Returns estimated token count."""
    if not files:
        print("  ⚠ No files to pack")
        return 0
    unique_files = list(dict.fromkeys(files))  # deduplicate preserving order
    include_arg = ",".join(unique_files)
    run(f'repomix --include "{include_arg}" --compress --output {output}')
    # Parse token count from Repomix stdout
    token_line = run(f'grep -i "token" {output} | head -1')
    print(f"  ↳ Packed {len(unique_files)} files → {output}")
    return len(unique_files)


def gather_files(searches: list[tuple[str, int]]) -> list[str]:
    """Run multiple CocoIndex searches and collect unique files."""
    all_files = []
    for query, top_k in searches:
        found = cocoindex_search(query, top_k)
        all_files.extend(found)
        print(f"  ↳ '{query[:50]}...' → {len(found)} files")
    return all_files


def claude_code(prompt_file: Path, context_file: Path, output_file: Path):
    """
    Invoke Claude Code with a prompt file and context.
    In practice, this is the Claude Code session — you run this interactively.
    This function prints the command to run.
    """
    print(f"\n  ┌─ Claude Code task ───────────────────────────────")
    print(f"  │  Prompt:  {prompt_file}")
    print(f"  │  Context: {context_file}")
    print(f"  │  Output:  {output_file}")
    print(f"  │")
    print(f"  │  Run:")
    print(f"  │    claude \\")
    print(f"  │      --context {context_file} \\")
    print(f"  │      --file {prompt_file}")
    print(f"  └──────────────────────────────────────────────────\n")


def section(title: str):
    print(f"\n{'═' * 60}")
    print(f"  {title}")
    print(f"{'═' * 60}")


# ── Pipeline steps ────────────────────────────────────────────────────────────

def step_update_index():
    section("Step 1 — Update CocoIndex")
    run(f"python {COCOINDEX_SCRIPT} cocoindex update", capture=False)
    print("  ✓ Index updated")


def step_architecture():
    section("Step 2 — Architecture Overview")
    DOCS_DIR.joinpath("architecture").mkdir(parents=True, exist_ok=True)

    files = gather_files(SEARCHES["architecture"])
    context = TMP / "arch-context.xml"
    repomix_pack(files, context)

    claude_code(
        PROMPTS_DIR / "architecture-overview.md",
        context,
        DOCS_DIR / "architecture" / "overview.md"
    )


def step_module(name: str, path: str):
    section(f"Module Guide — {name}")
    DOCS_DIR.joinpath("modules").mkdir(parents=True, exist_ok=True)

    searches = [
        (f"{name} public interface exports functions classes", 10),
        (f"{name} internal implementation logic", 10),
        (f"imports {path} uses {name} depends on", 8),
        (f"{name} dependencies imports external calls", 6),
        (f"test {name} spec describe should", 8),
        (f"{name} configuration setup options", 4),
    ]
    files = gather_files(searches)
    context = TMP / f"module-{name}-context.xml"
    repomix_pack(files, context)

    # Inject variables into prompt
    prompt_template = (PROMPTS_DIR / "module-guide.md").read_text()
    filled_prompt = (
        prompt_template
        .replace("{MODULE_NAME}", name)
        .replace("{MODULE_PATH}", path)
        .replace("{OUTPUT_PATH}", f"docs/modules/{name.lower()}.md")
    )
    filled_prompt_path = TMP / f"module-{name}-prompt.md"
    filled_prompt_path.write_text(filled_prompt)

    claude_code(
        filled_prompt_path,
        context,
        DOCS_DIR / "modules" / f"{name.lower()}.md"
    )


def step_api():
    section("API Reference")
    DOCS_DIR.joinpath("api").mkdir(parents=True, exist_ok=True)

    files = gather_files(SEARCHES["api"])
    context = TMP / "api-context.xml"
    repomix_pack(files, context)

    claude_code(
        PROMPTS_DIR / "api-reference.md",
        context,
        DOCS_DIR / "api" / "reference.md"
    )


def step_refresh(doc_path: str):
    section(f"Doc Refresh — {doc_path}")

    doc = Path(doc_path)
    if not doc.exists():
        print(f"  ✗ Doc not found: {doc_path}")
        sys.exit(1)

    # Infer topic from doc content
    content = doc.read_text()
    first_heading = next(
        (l.lstrip("#").strip() for l in content.splitlines() if l.startswith("#")),
        doc.stem
    )

    searches = [
        (f"{first_heading} implementation", 10),
        (f"{first_heading} interface exports public", 8),
        (f"{first_heading} dependencies", 6),
    ]
    files = gather_files(searches)
    context = TMP / f"refresh-context.xml"
    repomix_pack(files, context)

    prompt_template = (PROMPTS_DIR / "doc-refresh.md").read_text()
    filled_prompt = (
        prompt_template
        .replace("{DOC_PATH}", doc_path)
        .replace("{MODULE_PATH}", "")
        .replace("{TOPIC}", first_heading)
    )
    filled_prompt_path = TMP / "refresh-prompt.md"
    filled_prompt_path.write_text(filled_prompt)

    claude_code(filled_prompt_path, context, doc)


def step_resolve():
    section("Assumption Resolution")
    result = run("grep -rn '\\[ASSUMPTION' docs/ --include='*.md'")
    if not result:
        print("  ✓ No [ASSUMPTION] flags found — docs are clean")
        return

    count = len(result.splitlines())
    print(f"  Found {count} assumption(s) to resolve:\n")
    for line in result.splitlines():
        print(f"    {line}")

    claude_code(
        PROMPTS_DIR / "assumption-resolver.md",
        Path("docs"),
        Path("docs")
    )


def step_discover_modules() -> list[tuple[str, str]]:
    """Auto-discover top-level modules from directory structure."""
    section("Discovering modules")
    modules = []
    ignore = {
        "node_modules", "vendor", "dist", "build", "target",
        ".git", "__pycache__", "docs", ".claude"
    }
    for item in sorted(Path(".").iterdir()):
        if item.is_dir() and item.name not in ignore and not item.name.startswith("."):
            name = item.name.replace("_", " ").replace("-", " ").title()
            modules.append((name, str(item)))
            print(f"  ↳ Found module: {name} ({item})")
    return modules


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Codebase documentation pipeline")
    parser.add_argument("--mode", required=True,
        choices=["full", "architecture", "module", "api", "refresh", "resolve"],
        help="Pipeline mode to run")
    parser.add_argument("--name", help="Module name (for --mode module)")
    parser.add_argument("--path", help="Module path (for --mode module)")
    parser.add_argument("--doc", help="Doc file path (for --mode refresh)")
    args = parser.parse_args()

    print(f"\n{'═' * 60}")
    print(f"  Codebase Documentation Pipeline")
    print(f"  Mode: {args.mode.upper()}  |  {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"{'═' * 60}")

    # Always update the index first
    step_update_index()

    if args.mode == "full":
        step_architecture()
        modules = step_discover_modules()
        for name, path in modules:
            step_module(name, path)
        step_api()
        step_resolve()

    elif args.mode == "architecture":
        step_architecture()

    elif args.mode == "module":
        if not args.name or not args.path:
            print("--mode module requires --name and --path")
            sys.exit(1)
        step_module(args.name, args.path)

    elif args.mode == "api":
        step_api()

    elif args.mode == "refresh":
        if not args.doc:
            print("--mode refresh requires --doc")
            sys.exit(1)
        step_refresh(args.doc)

    elif args.mode == "resolve":
        step_resolve()

    print(f"\n{'═' * 60}")
    print(f"  ✓ Pipeline complete")
    print(f"  Run 'mkdocs serve' to preview docs at http://localhost:8000")
    print(f"{'═' * 60}\n")


if __name__ == "__main__":
    main()
