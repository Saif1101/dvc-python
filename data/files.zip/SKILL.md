---
name: codebase-documentation
description: >
  Use this skill when asked to generate, update, or maintain external documentation
  for a codebase using the CocoIndex + Repomix + Claude Code pipeline. Triggers include:
  "document this codebase", "generate module guides", "write architecture overview",
  "create API reference", "refresh outdated docs", or any request to produce structured
  external documentation from source code. Covers: architecture overviews, module/component
  guides, API references, and incremental doc refresh workflows.
---

# Codebase Documentation Skill

## Overview

You document codebases using a three-tool pipeline:

| Tool | Role | When |
|------|------|------|
| `ccc search` | Semantic search — finds relevant files via CocoIndex | Before every doc task |
| `repomix` | Packages found files into LLM-readable XML | After every search |
| You (Claude Code) | Reads context, writes docs, iterates | After every pack |

**NEVER** write docs from memory or training data alone. Always ground every doc in
actual code retrieved through this pipeline.

---

## Core Workflow — Follow Every Time

### Step 0: Update the index
```bash
python index_flow.py cocoindex update
```
Run this once at the start of every session to catch any code changes.

### Step 1: Search with CocoIndex
```bash
ccc search "<descriptive natural language query>" --top-k 12
```
- Use natural language, not file names or identifiers
- Run multiple searches for complex topics (entry points, dependencies, config)
- Capture the returned file list

### Step 2: Pack with Repomix
```bash
repomix --include "<comma-separated file paths from step 1>" \
        --compress \
        --output /tmp/repomix-context.xml
```
- Always use `--compress` to reduce token count
- If token count > 100k, reduce `--top-k` in step 1 or be more specific in the query
- Check token count in Repomix output before proceeding

### Step 3: Read and write
- Read `/tmp/repomix-context.xml` fully before writing anything
- Write docs to the specified output path
- Flag inferences with `[ASSUMPTION: <what you assumed and why>]`

### Step 4: Verify assumptions
For each `[ASSUMPTION]` you wrote:
```bash
ccc search "<targeted query to verify the assumption>" --top-k 5
repomix --include "<results>" --compress --output /tmp/verify.xml
```
Read `/tmp/verify.xml` and correct or confirm the assumption. Replace resolved
assumptions with confirmed facts.

### Step 5: Cross-check coverage
After writing each doc, run one more search to check you didn't miss key files:
```bash
ccc search "<topic> implementation details edge cases" --top-k 8
```
If new relevant files appear that weren't in the original pack, read them and
amend the doc.

---

## Document Types and Prompts

Load the appropriate prompt file from `prompts/` for each doc type:

| Doc Type | Prompt File | Output Path |
|----------|-------------|-------------|
| Architecture overview | `prompts/architecture-overview.md` | `docs/architecture/overview.md` |
| Module guide | `prompts/module-guide.md` | `docs/modules/<name>.md` |
| API reference | `prompts/api-reference.md` | `docs/api/reference.md` |
| Doc refresh | `prompts/doc-refresh.md` | Existing doc, updated in place |
| Assumption resolver | `prompts/assumption-resolver.md` | Inline correction |

---

## Search Query Patterns

Use these query patterns as starting points:

```
# Architecture / entry points
"main entry points application bootstrap startup initialization"
"core business logic domain models central abstractions"
"external integrations third-party services API clients"
"database layer data access repositories models"
"configuration environment settings feature flags"

# Module-specific
"<module name> public interface exports"
"<module name> internal logic implementation"
"<module name> dependencies imports"
"<module name> error handling edge cases"

# API
"HTTP routes endpoints handlers controllers"
"request validation middleware authentication"
"response serialization formatters"

# Cross-cutting
"shared utilities helpers common functions"
"error types exceptions custom errors"
"tests for <module name>"  ← tests reveal intent
```

**Pro tip**: Query tests and test files. They reveal intended behaviour that production
code often obscures, especially in legacy codebases.

---

## Token Budget Rules

| Context size | Action |
|---|---|
| < 50k tokens | Proceed normally |
| 50k–100k tokens | Fine, but consider splitting into two passes |
| 100k–150k tokens | Add `--ignore "**/test*,**/*.spec.*"` to Repomix |
| > 150k tokens | Split: document subsystems separately, synthesize last |

---

## Output Quality Rules

1. **Ground every claim** — if you can't point to a file in your Repomix context
   that supports a statement, flag it as `[ASSUMPTION]`
2. **Flag legacy smells** — note `[LEGACY: this pattern is outdated because ...]`
   when you spot deprecated patterns, so readers know what to expect
3. **Link between docs** — reference other module guides when documenting dependencies
4. **Write for a new hire** — assume the reader knows the language but nothing about
   this specific codebase
5. **Mermaid diagrams** — always include one in architecture overviews and module
   guides that have non-trivial dependencies; use `graph TD` or `sequenceDiagram`

---

## Session Initialisation Prompt

At the start of a new documentation session, say this to orient yourself:

```
I am documenting a legacy codebase using the CocoIndex + Repomix pipeline.
My workflow is:
  1. ccc search → find relevant files
  2. repomix --include <files> --compress → pack context
  3. Read context → write doc → flag assumptions
  4. ccc search again → verify assumptions
  5. Repeat per module / section

I will not write documentation I cannot ground in retrieved source code.
I will flag every inference with [ASSUMPTION: ...].
I will run cocoindex update at the start of this session.
```
