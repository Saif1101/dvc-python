# Prompt: Doc Refresh

## When to use
When code has changed since the docs were last generated and you need to
update specific docs without regenerating everything from scratch.
This is the incremental maintenance workflow.

---

## Variables
- `{DOC_PATH}` — path to the doc to refresh, e.g. `docs/modules/auth.md`
- `{MODULE_PATH}` — the code path the doc covers, e.g. `src/auth`
- `{TOPIC}` — plain English description, e.g. "authentication and session management"

---

## Pre-flight

```bash
# 1. Update the CocoIndex to reflect recent changes
python index_flow.py cocoindex update

# 2. Find current relevant files
ccc search "{TOPIC}" --top-k 12

# 3. Pack fresh context
repomix --include "<results from step 2>" \
        --compress \
        --output /tmp/refresh-context.xml
```

---

## Prompt

```
You are refreshing an existing documentation file for a legacy codebase.
The codebase has changed since this doc was written.

Existing doc: {DOC_PATH}
Code covered: {MODULE_PATH}
Fresh context: /tmp/refresh-context.xml

Instructions:

1. READ the existing doc at {DOC_PATH} in full.

2. READ the fresh context at /tmp/refresh-context.xml in full.

3. DIFF mentally: identify every place where the doc and the code disagree.
   Look specifically for:
   - Function signatures that changed
   - New public functions/endpoints not in the doc
   - Removed functions/endpoints still in the doc
   - Behaviour descriptions that no longer match the code
   - Config keys added, removed, or renamed
   - New dependencies or removed dependencies
   - New error types or changed error handling

4. CLASSIFY each discrepancy:
   - OUTDATED: doc says X, code says Y — update doc to match code
   - MISSING: code has X, doc doesn't mention it — add to doc
   - STALE: doc mentions X, code no longer has it — remove from doc
   - UNCERTAIN: can't tell from context alone — flag as [NEEDS REVIEW: ...]

5. PRODUCE an updated version of {DOC_PATH} with all changes applied.
   Do not rewrite sections that haven't changed.
   At the bottom, add a "Last Refreshed" section:

   ---
   ## Changelog
   *Refreshed on <date>*
   - Updated: `functionX` signature changed — now accepts `opts` parameter
   - Added: `functionY` — new export added in recent refactor
   - Removed: `legacyZ` — no longer exported
   - [NEEDS REVIEW]: rate limiting behaviour unclear from available context

6. After updating, run:
   ```bash
   ccc search "{TOPIC} recent changes new features refactor" --top-k 6
   ```
   Check if any recently changed files were missed. Amend if needed.

Resolve every [ASSUMPTION] from the original doc that you now have evidence for.
```
