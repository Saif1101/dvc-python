# CocoIndex + Repomix + Claude Code — Documentation Pipeline

A three-tool pipeline for generating accurate, grounded external documentation
from a legacy codebase. No hallucination. Every claim traced to source code.

---

## File Structure

```
.claude/
├── skills/
│   └── SKILL.md                  ← Claude Code reads this at session start
├── prompts/
│   ├── architecture-overview.md  ← Prompt for architecture doc
│   ├── module-guide.md           ← Prompt for module guides
│   ├── api-reference.md          ← Prompt for API reference
│   ├── doc-refresh.md            ← Prompt for refreshing stale docs
│   └── assumption-resolver.md    ← Prompt for resolving [ASSUMPTION] flags
├── agents/
│   └── doc-agent-system.md       ← System prompt for the doc agent
└── orchestrate.py                ← Orchestration script
```

---

## Quick Start

### 1. Install dependencies
```bash
pip install cocoindex cocoindex-code
npm install -g repomix
pip install mkdocs-material
```

### 2. Set up CocoIndex
```bash
# Copy index_flow.py to your repo root (see architecture guide)
export COCOINDEX_DATABASE_URL="postgresql://localhost/cocoindex"
python index_flow.py cocoindex update
```

### 3. Run the pipeline

**Full generation (all docs from scratch):**
```bash
python .claude/orchestrate.py --mode full
```

**Single module:**
```bash
python .claude/orchestrate.py --mode module --name "Auth" --path "src/auth"
```

**Architecture overview only:**
```bash
python .claude/orchestrate.py --mode architecture
```

**API reference only:**
```bash
python .claude/orchestrate.py --mode api
```

**Refresh a specific doc after code changes:**
```bash
python .claude/orchestrate.py --mode refresh --doc docs/modules/auth.md
```

**Resolve all [ASSUMPTION] flags:**
```bash
python .claude/orchestrate.py --mode resolve
```

### 4. Start a Claude Code session

The orchestrator prints the Claude Code command for each task. Run it:

```bash
claude \
  --context /tmp/arch-context.xml \
  --file .claude/prompts/architecture-overview.md
```

At the start of each session, tell Claude Code to read the skill:
```
Read .claude/skills/SKILL.md and follow it for this session.
```

### 5. Preview the docs
```bash
mkdocs serve
# http://localhost:8000
```

---

## How It Works

```
ccc search "<topic>"
      │
      │  ranked file list
      ▼
repomix --include <files> --compress
      │
      │  scoped XML context
      ▼
Claude Code reads SKILL.md + prompt + context
      │
      │  writes doc, flags assumptions
      ▼
docs/**.md
      │
      │  assumption resolver pass
      ▼
ccc search (targeted verification queries)
      │
      │  confirms or corrects
      ▼
clean docs with no unresolved [ASSUMPTION] flags
```

---

## Flags Used in Generated Docs

| Flag | Meaning |
|------|---------|
| `[ASSUMPTION: ...]` | Inferred, not read directly from code — needs verification |
| `[LEGACY: ...]` | Outdated pattern spotted — readers should be cautious |
| `[GAP: ...]` | Information missing from available context |
| `[NEEDS HUMAN REVIEW: ...]` | Could not resolve after multiple search attempts |

Run the assumption resolver to clear as many of these as possible.
The remainder go to a human for final verification.

---

## Incremental Refresh

When code changes, you don't regenerate everything. CocoIndex only re-indexes
changed files, and the refresh prompt only rewrites changed sections.

```bash
# After a code change:
python index_flow.py cocoindex update

# Refresh the affected doc:
python .claude/orchestrate.py --mode refresh --doc docs/modules/payments.md
```

---

## Tips for Legacy Codebases

- **Search tests first** — test files reveal intended behaviour that production
  code obscures. Always include test searches in your queries.
- **Flag legacy patterns aggressively** — [LEGACY] notes are valuable to readers.
  Don't sanitise them out.
- **Document one module per Claude Code session** — context quality drops for
  very long sessions. Fresh sessions per module give better results.
- **Leave [NEEDS HUMAN REVIEW] in** — it's better to flag uncertainty than to
  present a hallucinated fact as truth in a legacy codebase doc.
