# Prompt: API Reference

## When to use
Generate this after module guides exist. The API reference documents the
external-facing surface of the system — HTTP endpoints, public SDK methods,
CLI commands, or event interfaces, depending on the codebase type.

Detect which applies from the code and use the relevant section template.

---

## Pre-flight searches

```bash
# 1. HTTP routes / endpoints
ccc search "HTTP routes endpoints URL path GET POST PUT DELETE PATCH" --top-k 12

# 2. Controllers / handlers
ccc search "controller handler request response route handler" --top-k 10

# 3. Authentication / authorisation on endpoints
ccc search "authentication authorisation middleware guard protect route" --top-k 8

# 4. Request validation / schemas
ccc search "request validation schema body params query validator" --top-k 8

# 5. Response serialisation
ccc search "response serializer formatter output transform" --top-k 6

# 6. Error responses
ccc search "error response status code HTTP error handler" --top-k 6

# 7. Rate limiting / throttling
ccc search "rate limit throttle quota request limit" --top-k 4

# 8. API tests — reveal expected behaviour
ccc search "API test integration test endpoint test supertest request spec" --top-k 10
```

Pack results:
```bash
repomix --include "<all files from above, deduplicated>" \
        --compress \
        --output /tmp/api-context.xml
```

---

## Prompt

```
You are writing an API Reference for a legacy codebase.
Output: docs/api/reference.md
Source: /tmp/api-context.xml

Read the full file including test files — integration tests are the most
reliable source of truth for API behaviour in legacy codebases.

Detect whether this is a REST API, GraphQL API, SDK library, CLI tool,
or event-driven interface. Document whatever external surface you find.

Write docs/api/reference.md using this structure:

---

# API Reference

## Overview
What kind of API is this (REST / GraphQL / SDK / CLI / events)?
Base URL, versioning scheme, and content type conventions.
Where to find credentials / API keys.

## Authentication
How callers authenticate. Show the actual header/param/mechanism.
```
Authorization: Bearer <token>
```
How to obtain credentials. Token expiry and refresh if applicable.

## Endpoints

For each endpoint, use this template:

---

### `METHOD /path/to/endpoint`

**Description**
What this endpoint does. When to use it.

**Authentication required**: Yes / No / Role: <role>

**Path parameters**
| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | string | The resource identifier |

**Query parameters**
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `page` | integer | No | 1 | Page number |

**Request body** (if applicable)
```json
{
  "field": "value"
}
```

**Response**
```json
{
  "id": "abc123",
  "field": "value"
}
```

**Error responses**
| Status | Code | Description |
|--------|------|-------------|
| 400 | VALIDATION_ERROR | Missing required field |
| 401 | UNAUTHORIZED | Token missing or expired |
| 404 | NOT_FOUND | Resource does not exist |

---

Group endpoints by resource or domain. Use H2 headers for groups:
## Users
## Orders
## etc.

## Common Patterns
Pagination, filtering, sorting conventions used across endpoints.
Any non-obvious behaviour that applies globally.

## Rate Limiting
Limits, headers returned, backoff recommendations.
[ASSUMPTION] or [GAP] if not found in the code.

## Errors
Global error format. The shape of every error response.
List all error codes if they're defined in the codebase.

## Versioning
How API versions work. Deprecation policy if visible from the code.
[LEGACY] notes for deprecated endpoints still in the code.

---

After writing, run:
```bash
ccc search "API undocumented hidden endpoint internal route" --top-k 6
```
Check for any endpoints that weren't caught in initial searches.
Flag them with [GAP: endpoint found but not fully documented] if you can't
retrieve enough context to document them fully.

Mark every unresolved inference with [ASSUMPTION] and list them in a
"Needs Human Review" section at the end.
```
